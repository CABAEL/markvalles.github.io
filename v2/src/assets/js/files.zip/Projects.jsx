import React from "react";
import {
  Typography,
  Link,
  Grid,
  Box,
  Container,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import { motion as Motion } from 'framer-motion';
import thesis from '../pdf/THESIS_WTSK.pdf'
import wais from '../pdf/WAIS_MANUAL.pdf'
import { accentPalette } from './designTokens';

const projects = [
  {
    type: "MAX AI VOICE ASSISTANT",
    name: "MAX AI",
    description:
      "AI Assistant hosted using LM Studio, integrated with Node.js and Python for voice interaction.",
    link: "https://github.com/CABAEL/max_ai",
    linkText: "View Repo",
  },
  {
    type: "HR Management System",
    name: "HRMS",
    description:
      "For sale to Customize, HR system for small teams—includes employee profiles, DTR, and payroll.",
    link: "https://github.com/CABAEL/HRMS.git",
    linkText: "View Repo",
  },
  {
    type: "Sales Software",
    name: "The Sales Machine",
    description:
      "Creating API and organizing controllers for the backend using Code Igniter and jQuery for Frontend.",
    link: "https://thesalesmachine.com/",
    linkText: "Visit Site",
  },
  {
    type: "Document Management System",
    name: "QRSYS",
    description:
      "Secure document management with unique QR codes for fast access and verification, roles, and password protection.",
    link: "https://github.com/CABAEL/qrsys",
    linkText: "View Repo",
  },
  {
    type: "Testing Tool",
    name: "WTSK - WEB TESTING STARTER KIT",
    description:
      "Thesis project where I was the main developer and concept creator, made with PHP and Selenium PHP plugin.",
    link: thesis,
    linkText: "View PDF",
  },
  {
    type: "Blockchain Voting System",
    name: "Voting System",
    description:
      "2nd place in a training activity competition. Built with Vue, Solidity, and Remix.",
    link: "https://github.com/CABAEL/blockchain_voting_system",
    linkText: "View Repo",
  },
  {
    type: "DOST-PCIEERD Agency Tracker",
    name: "Strategic Performance Management System",
    description:
      "Agency system to track targets and productivity with semester reports.",
    link: "",
    linkText: "Hosted under private domain",
  },
  {
    type: "Inventory Management",
    name: "WAIS - WAREHOUSE AUTOMATED INVENTORY SYSTEM",
    description:
      "Full stack outsourced project for PNP SMS OFFICE Inventory Prototype Software.",
    link: wais,
    linkText: "View PDF",
  },
  {
    type: "Record Management",
    name: "Record Office Application Solution",
    description:
      "Successfully implemented for record office sector of Taguig City Hall. Presented by my co-dev Mr. Rasdi Kasim.",
    link: "https://www.dailymotion.com/embed/video/x7ushww",
    linkText: "Watch Demo Video",
  },
  {
    type: "Company Website",
    name: "Peacemaker Filmworks East",
    description:
      "WordPress site for a specialty camera team and service provider to the Canadian film & television industry.",
    link: "https://peacemakerfilmworkseast.com/",
    linkText: "Visit Site",
  },
];

const ProjectsList = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  return (
    <Container maxWidth="lg" sx={{ color: "#FFFFFF", minHeight: "auto" }}>
      <Typography
        variant={isMobile ? "h5" : "h4"}
        align="center"
        fontWeight="bold"
        gutterBottom
        sx={{ pt: 5, color: '#ffff', textShadow: '1px 1px 2px #000' }}
      >
        Featured Projects
      </Typography>
      <Typography variant="h6" align="center" sx={{ mb: 6, color: '#F0F0F0' }}>
        Showcasing innovative solutions and technical expertise
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        {projects.map((project, index) => {
          const accent = accentPalette[index % accentPalette.length];
          return (
            <Grid item key={index} xs={12} sm={6} md={4}>
              <Motion.div
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.4, delay: (index % 3) * 0.06 }}
                style={{ height: '100%' }}
              >
                <Box
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    p: 3,
                    pl: 3.25,
                    borderRadius: '12px',
                    bgcolor: '#15161a',
                    border: '1px solid rgba(255,255,255,0.07)',
                    borderLeft: `2px solid ${accent}`,
                    transition: 'background-color 0.25s ease, transform 0.25s ease, border-color 0.25s ease',
                    '&:hover': {
                      bgcolor: '#18181c',
                      transform: 'translateY(-2px)',
                      borderColor: 'rgba(255,255,255,0.12)',
                    },
                  }}
                >
                  <Typography
                    sx={{ color: '#8A8A8E', fontSize: '0.72rem', fontWeight: 500, mb: 1, textTransform: 'capitalize' }}
                  >
                    {project.type.toLowerCase()}
                  </Typography>
                  <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#FFFFFF', mb: 0.75, lineHeight: 1.3 }}>
                    {project.name}
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#9A9A9E', mb: 2, lineHeight: 1.55, flexGrow: 1 }}>
                    {project.description}
                  </Typography>
                  {project.link ? (
                    <Link
                      href={project.link}
                      target="_blank"
                      rel="noopener"
                      sx={{
                        alignSelf: 'flex-start',
                        color: accent,
                        fontSize: '0.85rem',
                        fontWeight: 600,
                        textDecoration: 'none',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 0.5,
                        '&:hover': { textDecoration: 'underline' },
                      }}
                    >
                      {project.linkText} →
                    </Link>
                  ) : (
                    <Typography variant="caption" sx={{ color: '#5C5C60', fontWeight: 600 }}>
                      {project.linkText}
                    </Typography>
                  )}
                </Box>
              </Motion.div>
            </Grid>
          );
        })}
      </Grid>
    </Container>
  );
};

export default ProjectsList;
