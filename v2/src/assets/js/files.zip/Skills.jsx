import React from 'react';
import { Box, Typography, Card, CardContent, Chip, Stack, Grid } from '@mui/material';
import { Code, Storage, Build, BugReport, Computer, Brush } from '@mui/icons-material';
import { motion } from 'framer-motion';
import { getAccent } from './designTokens';

const MotionCard = motion(Card);

const getSkillIcon = (title) => {
  const icons = {
    'Popular Web Development Stack': <Code fontSize="small" />,
    'Back-end & API': <Storage fontSize="small" />,
    'Dev Tools & Workflow': <Build fontSize="small" />,
    'Testing & Deployment': <BugReport fontSize="small" />,
    'IT & Support': <Computer fontSize="small" />,
    'Media & Content': <Brush fontSize="small" />,
  };
  return icons[title] || <Code fontSize="small" />;
};

const About = ({ dimmed }) => {
  const skillGroups = [
    {
      title: 'Popular Web Development Stack',
      items: ['JavaScript (JS)', 'HTML / CSS', 'React', 'PHP', 'Laravel', 'Bootstrap', 'jQuery'],
    },
    {
      title: 'Back-end & API',
      items: ['RESTful API', 'NodeJs', 'ExpressJS', 'MongoDB', 'CodeIgniter', 'Yii2', 'Redis'],
    },
    {
      title: 'Dev Tools & Workflow',
      items: ['Git', 'Bitbucket', 'SourceTree', 'Git Kraken', 'Postman', 'FTP / SSH / SFTP', 'Web hosting'],
    },
    {
      title: 'Testing & Deployment',
      items: ['Test case creation', 'Test Driven Development', 'Smart Contract deployment (Remix)', 'Deployment/Hosting', 'Local server setup for web apps'],
    },
    {
      title: 'IT & Support',
      items: ['PC networking (wired/wireless)', 'Basic PC troubleshooting', 'PC formatting and setup', 'Printer networking'],
    },
    {
      title: 'Media & Content',
      items: ['Multimedia editing (Adobe Suite, Audacity)', 'FL studio', 'Canva'],
    },
  ];

  return (
    <Box sx={{ py: 4, px: 2 }}>
      <Box sx={{ textAlign: 'center', mb: 5 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom sx={{ color: '#F0F0F0' }}>
          Technical Skills
        </Typography>
        <Typography variant="h6" sx={{ mb: 2, color: '#D0D0D0' }}>
          Technologies and tools I work with
        </Typography>
        <Chip
          label={`${skillGroups.length} Skill Categories`}
          sx={{ color: '#B0B0B0', borderColor: 'rgba(255,255,255,0.2)' }}
          variant="outlined"
        />
      </Box>

      <Grid container spacing={2.5}>
        {skillGroups.map(({ title, items }, index) => {
          const accent = getAccent(index);
          return (
            <Grid item xs={12} sm={6} key={title}>
              <MotionCard
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.5, delay: (index % 2) * 0.08 }}
                whileHover={{ y: -3 }}
                sx={{
                  height: '100%',
                  bgcolor: '#15161a',
                  border: '1px solid rgba(255,255,255,0.07)',
                  borderLeft: `2px solid ${accent}`,
                  borderRadius: '12px',
                  boxShadow: 'none',
                  transition: 'background-color 0.25s ease',
                  '&:hover': { bgcolor: '#18181c' },
                }}
              >
                <CardContent sx={{ p: 2.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1.75 }}>
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: 32,
                        height: 32,
                        borderRadius: '8px',
                        bgcolor: `${accent}1f`,
                        color: accent,
                        mr: 1.5,
                      }}
                    >
                      {getSkillIcon(title)}
                    </Box>
                    <Typography variant="subtitle1" fontWeight={700} sx={{ fontSize: '1rem', color: '#F0F0F0' }}>
                      {title}
                    </Typography>
                  </Box>

                  <Stack direction="row" flexWrap="wrap" gap={0.7}>
                    {items.map((item, i) => (
                      <Chip
                        key={i}
                        label={item}
                        size="small"
                        variant="outlined"
                        sx={{
                          color: '#C4C4C8',
                          borderColor: 'rgba(255,255,255,0.14)',
                          bgcolor: 'rgba(255,255,255,0.03)',
                          fontSize: '0.72rem',
                          height: '26px',
                          '&:hover': {
                            bgcolor: `${accent}1f`,
                            borderColor: accent,
                            color: '#fff',
                          },
                        }}
                      />
                    ))}
                  </Stack>
                </CardContent>
              </MotionCard>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};

export default About;
