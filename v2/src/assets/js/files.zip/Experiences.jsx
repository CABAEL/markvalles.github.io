import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { motion as Motion } from 'framer-motion';
import { getAccent } from './designTokens';

const ExpList = ({ dimmed }) => {
  const textColor = '#fff';
  const linkColor = '#aed1e8';

  const experiences = [
    {
      company: "Ascendion (Previously Collabera Digital)",
      link: "https://ascendion.com/what-we-do/",
      role: "Fullstack Engineer",
      dates: "Aug 19, 2024 - Present",
      current: true,
    },
    {
      company: "DYNAMIC STRATEGY SOLUTIONS EXPERTS CORPORATION",
      link: "https://dsseservices.com/about",
      role: "Intermediate PHP Developer",
      dates: "Nov 28, 2022 - May 31, 2024"
    },
    {
      company: "YEMPO",
      link: "https://www.yempo-solutions.com/",
      role: "PHP Developer",
      dates: "Oct 04, 2022 - Nov 18, 2022"
    },
    {
      company: "DOST-PCIEERD",
      link: "https://pcieerd.dost.gov.ph/",
      role: "Information System Analyst II",
      dates: "Jan 4, 2022 – Sep 30, 2022"
    },
    {
      company: "DBP Service Corporation (Client assignment: DOST-PCIEERD)",
      link: "https://pcieerd.dost.gov.ph/",
      role: "Project Technical Specialist I",
      dates: "Oct 5, 2021 – Dec 31, 2021"
    },
    {
      company: "Optimo International",
      link: "https://dev.optimointernational.com/who-we-are/",
      role: "PHP Developer",
      dates: "Nov 3, 2020 – Oct 1, 2021"
    },
    {
      company: "7rivers Frontend Developer (Project Based)",
      link: "https://7rivers.ph/",
      role: "",
      dates: "July 8, 2020 – Aug 31, 2020"
    },
    {
      company: "Healthcare representative BPO (TaskUs)",
      role: "",
      dates: "June 19, 2019 – Dec 31, 2019"
    },
    {
      company: "PNP CAMP BAGONG DIWA (WAIS) Prototype Developer Outsourced",
      role: "PHP Developer",
      dates: "Oct 12, 2018 – Dec 15, 2018"
    },
    {
      company: "DOST (DEPARTMENT OF SCIENCE AND TECHNOLOGY) - PCIEERD INTERN",
      role: "Laravel Developer",
      dates: "June 30, 2017 – Aug 31, 2017"
    },
    {
      company: "Freelance Web Developer since 2017"
    }
  ];

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
        gap: 2.5,
        p: 1,
      }}
    >
      {experiences.map((exp, i) => {
        const accent = getAccent(i);
        return (
          <Motion.div
            key={i}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.5, delay: (i % 4) * 0.06 }}
          >
            <Box
              sx={{
                height: '100%',
                p: 2.5,
                borderRadius: '12px',
                bgcolor: 'rgba(21, 22, 26, 0.72)',
                border: '1px solid rgba(255,255,255,0.07)',
                borderLeft: `2px solid ${accent}`,
                backdropFilter: 'blur(6px)',
                transition: 'background-color 0.25s ease, transform 0.25s ease',
                '&:hover': {
                  bgcolor: 'rgba(24, 24, 28, 0.85)',
                  transform: 'translateY(-2px)',
                },
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 1 }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 600, color: textColor, lineHeight: 1.35 }}>
                  {exp.link ? (
                    <a
                      href={exp.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: linkColor, textDecoration: 'none' }}
                    >
                      {exp.company}
                    </a>
                  ) : (
                    exp.company
                  )}
                </Typography>
                {exp.current && (
                  <Typography
                    sx={{
                      flexShrink: 0,
                      fontSize: '0.65rem',
                      fontWeight: 700,
                      color: accent,
                      bgcolor: `${accent}1f`,
                      borderRadius: '999px',
                      px: 1,
                      py: 0.25,
                      lineHeight: 1.6,
                    }}
                  >
                    Current
                  </Typography>
                )}
              </Box>
              {exp.role && (
                <Typography variant="body2" sx={{ color: '#B4B4B8', mt: 0.5 }}>
                  {exp.role}
                </Typography>
              )}
              {exp.dates && (
                <Typography variant="caption" sx={{ color: '#8A8A8E', fontStyle: 'italic', display: 'block', mt: 0.5 }}>
                  {exp.dates}
                </Typography>
              )}
            </Box>
          </Motion.div>
        );
      })}
    </Box>
  );
};

export default ExpList;
